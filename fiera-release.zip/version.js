window.FIERA_VERSION = '7.0.0';
